package cs;

public class CellularAutomata {
    private String ruleBinary;
    private int[] currentState;

    // Constructor
    public CellularAutomata(int width) {
        this.currentState = new int[width];
        this.currentState[width/2] = 1;  // Initialize with a single 1 in the center
    }

    public void setRule(int ruleNumber) {
        this.ruleBinary = String.format("%8s", Integer.toBinaryString(ruleNumber)).replace(' ', '0');
    }

    public int[] getNextState() {
        int[] nextState = new int[currentState.length];

        for (int i = 0; i < currentState.length; i++) {
            int left = (i == 0) ? 0 : currentState[i - 1];
            int center = currentState[i];
            int right = (i == currentState.length - 1) ? 0 : currentState[i + 1];
            String pattern = "" + left + center + right;
            int ruleIndex = Integer.parseInt(pattern, 2);
            nextState[i] = ruleBinary.charAt(7 - ruleIndex) == '1' ? 1 : 0;
        }

        currentState = nextState;
        return currentState;
    }
}